public class FooApp {
	public static void main(String[] args) {
		System.out.println(Payment.getPayment(7.50, 35));
		System.out.println(Payment.getPayment(8.20, 47));
		System.out.println(Payment.getPayment(10.00, 73));
	}
}
