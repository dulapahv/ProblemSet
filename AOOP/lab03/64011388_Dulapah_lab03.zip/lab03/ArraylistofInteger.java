import java.util.ArrayList;

public class ArraylistofInteger {
	public static void main(String[] args) {
		// TODO code application logic here
		ArrayList odds = new ArrayList();
		odds.add(new Integer(1));
		odds.add(3);
	}

}