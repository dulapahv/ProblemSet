public class Lecture3 {
	public static void main(String[] args) {
		int[] scores = new int[3];
		scores[0] = 23;
		scores[1] = 9;
		scores[2] = 10;
		System.out.println(scores.length);
		int[] array1 = { 12, 36 };
		System.out.println(array1.length);

	}
}
