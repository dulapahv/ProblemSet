public class Record {
	int num;
	String name;
}
