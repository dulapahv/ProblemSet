package InheritTest;

class ArtWork {
    ArtWork() {
        System.out.println("New ArtWork");
    }
}
