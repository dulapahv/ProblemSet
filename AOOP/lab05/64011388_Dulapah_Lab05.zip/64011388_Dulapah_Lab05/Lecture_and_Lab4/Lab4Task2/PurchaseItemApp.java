package Lab4Task2;

import javax.sound.midi.SysexMessage;

public class PurchaseItemApp {
    public static void main(String args[]){
        WeightedItem item1 = new WeightedItem("Banana", 3, 1.37);
        CountedItem item2 = new CountedItem(10, "pens", 4.5);
        System.out.println(item1.toString());
        System.out.println(item2.toString());

    }
}
