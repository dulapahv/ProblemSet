package ObjectClass;

public class TestDog {
    public static void main(String[] args){
        Dog d1,d2;
        d1 = new Dog("s");
        d2 = new Dog("s");

        System.out.println(d1.equals(d2));
    }
}
