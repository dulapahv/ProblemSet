package Lab7;

import java.util.Comparator;

public class CreatorComparator implements Comparator<CatalogItem> {
    @Override
    public int compare (CatalogItem o1, CatalogItem o2){
        return  o1.item.getCreator().compareTo(o2.item.getCreator());
    }
}
