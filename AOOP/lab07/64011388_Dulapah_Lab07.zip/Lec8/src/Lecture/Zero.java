package Lecture;

public class Zero {
    public static void main(String[] args) {
        int numberator = 10;
        int deniminator = 0;
        try {
            System.out.println(numberator / deniminator);
        }
        catch (ArithmeticException e) {
            System.out.println(e);
            System.out.println("This text not be printed");
        }
    }
}
