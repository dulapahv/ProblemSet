package ThrowDemo;

public class ThrowsDemo {
    static void throwOne() throws IllegalAccessException {
        System.out.println("Inside ThrowsOne()");
        throw new IllegalAccessException("Demo");
    }
}
