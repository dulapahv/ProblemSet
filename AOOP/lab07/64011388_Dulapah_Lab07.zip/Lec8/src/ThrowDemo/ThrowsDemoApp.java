package ThrowDemo;

public class ThrowsDemoApp {
    public static void main(String[] args) {
        try {
            ThrowsDemo.throwOne();
        } catch (IllegalAccessException e) {
            System.out.println("Catch " + e);

        }
    }
}
