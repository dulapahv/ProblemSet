package creatingexception;
public class OutOfRangeException extends Exception {
    OutOfRangeException(String message) {
        super(message);
    }

}
