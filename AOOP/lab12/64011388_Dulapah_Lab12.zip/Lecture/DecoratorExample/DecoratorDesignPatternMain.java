package DecoratorExample;

public class DecoratorDesignPatternMain {
    public static void main(String args[]) {
//        Room room = new SimpleRoom();
//        room=new ColorDecorator(room);
//        System.out.println(room.showRoom());
//        room=new CurtainDecorator(room);
//        System.out.println(room.showRoom());
        Room room = new CurtainDecorator(new ColorDecorator(new SimpleRoom()));
        System.out.println(room.showRoom());

    }
}
