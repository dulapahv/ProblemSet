package DecoratorExample;

public interface Room{
    public String showRoom();
}
