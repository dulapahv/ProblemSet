package DecoratorExample;

public class SimpleRoom implements Room {
    @Override
    public String showRoom() {
        return "Normal Room";
    }
}

