package SingletonExample;

public class NewMain {
    public static void main(String[] args) {
        Ball ball=Ball.getInstance("red");

    }
}
