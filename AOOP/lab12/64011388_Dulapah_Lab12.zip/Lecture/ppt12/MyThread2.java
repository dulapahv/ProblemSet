package ppt12;

class MyThread2 extends Thread {
    MyThread2() { start();}
    public void run() {
        for(int i = 0; i < 2000; i++) {
            System.out.println("run():  " + i);
        }
    }
}
