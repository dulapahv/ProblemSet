package ppt16;

public class DoARunnable2 {
    public static void main(String[] args) {
        new MyRunnable2();
        for(int i = 0; i < 2000; i++) {
            System.out.println("main(): " + i);
        }
    }
}
