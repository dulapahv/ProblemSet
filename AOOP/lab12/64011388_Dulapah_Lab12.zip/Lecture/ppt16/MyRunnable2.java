package ppt16;

class MyRunnable2 implements Runnable {
    MyRunnable2() {
        Thread t = new Thread(this);
        t.start();
    }
    public void run() {
        for(int i = 0; i < 2000; i++) {
            System.out.println("run():  " + i);
        }
    }
}
