package ppt17;

class MyRunner implements Runnable {
    String text;
    MyRunner(String s) {
        text = s;
    }
    public void run() {
        for(int i = 0; i < 500 ; i++) {
            System.out.println( text + i );
        }
    }
}
