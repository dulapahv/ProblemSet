package ppt23;

class MyQuitable2 implements Runnable {
    boolean go = true;
    public void quit() {go = false;}
    public void run() {
        for(int i = 0; go ; i++) {
            System.out.println("run():  " + i);
        }
    }
}

