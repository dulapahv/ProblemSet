package ppt25;

class MyDaemon implements Runnable {
    public void run() {
        for(int i = 0;  true   ; i++) {
            System.out.println("run():  " + i);
        }
    }
}
