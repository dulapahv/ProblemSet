package ppt27;

public class DoMySleep {
    public static void main(String[] args) {
        MySleep ms = new MySleep();
        Thread t = new Thread(ms);
        t.start();

        for(int i = 0; i < 2000; i++) {
            System.out.println("main(): " + i );
        }
    }
}
