package ppt27;

class MySleep implements Runnable {
    public void run() {
        for(int i = 0; i < 2000; i++) {
            System.out.println("run() : " + i );
            if(i == 500) {
                System.out.println("Nap Time");
                try {Thread.currentThread().sleep(5000);//milli seconds
                }catch(Exception e) { e.printStackTrace(); }
            }
        }
    }
}
