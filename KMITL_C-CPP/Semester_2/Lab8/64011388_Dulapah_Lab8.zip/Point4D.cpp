/** Point4D class **/

#include <iostream>
#include <limits>
#include "assert.h"
#include "math.h"

using namespace std;

#include "Point4D.h"

#include "DivideByZeroException.h"
#include "OverflowException.h"

template <typename T>
void Point4D<T>::print(ofstream& f) {
	assert(f);
	f << "(" << getX() << ", " << getY() << ", " << getZ() << ", " << z4 << ")";
}

template <typename T>
void Point4D<T>::print() {
	cout << "(" << getX() << ", " << getY() << ", " << getZ() << ", " << z4 << ")";
}

/* + operator method */
template <typename T>
inline Point4D<T> Point4D<T>::operator+(Point4D<T>& p) {
	/* Check for overflow of given data type. If it does not overflow, compute the result */
	T chk[4] = { getX(), getY(), getZ(), z4 };
	T pChk[4] = { p.getX(), p.getY(), p.getZ(), p.z4 };
	for (int i = 0; i < 4; i++) {
		if ((pChk[i] > 0) && (chk[i]) > numeric_limits<T>::max() - pChk[i]) { throw OverflowException(); }
		if ((pChk[i] < 0) && (chk[i]) < numeric_limits<T>::lowest() - pChk[i]) { throw OverflowException(); }
	}

	return Point4D<T>(getX() + p.getX(), getY() + p.getY(), getZ() + p.getZ(), z4 + p.z4);
}

/* - operator method */
template <typename T>
inline Point4D<T> Point4D<T>::operator-(Point4D<T>& p) {
	/* Check for overflow of given data type. If it does not overflow, compute the result */
	T chk[4] = { getX(), getY(), getZ(), z4 };
	T pChk[4] = { p.getX(), p.getY(), p.getZ(), p.z4 };
	for (int i = 0; i < 4; i++) {
		if ((pChk[i] < 0) && (chk[i]) > numeric_limits<T>::max() + pChk[i]) { throw OverflowException(); }
		if ((pChk[i] > 0) && (chk[i]) < numeric_limits<T>::lowest() + pChk[i]) { throw OverflowException(); }
	}

	return Point4D<T>(getX() - p.getX(), getY() - p.getY(), getZ() - p.getZ(), z4 - p.z4);
}

/* * operator method */
template <typename T>
inline Point4D<T> Point4D<T>::operator*(Point4D<T>& p) {
	/* Check for overflow of given data type. If it does not overflow, compute the result */
	T chk[4] = { getX(), getY(), getZ(), z4 };
	T pChk[4] = { p.getX(), p.getY(), p.getZ(), p.z4 };
	for (int i = 0; i < 4; i++) {
		if ((chk[i] == -1) && (chk[i] == numeric_limits<T>::lowest())) { throw OverflowException(); }
		if ((chk[i] == -1) && (pChk[i] == numeric_limits<T>::lowest())) { throw OverflowException(); }
		if (pChk[i] > numeric_limits<T>::max() / chk[i]) { throw OverflowException(); }
		if ((pChk[i] < numeric_limits<T>::lowest() / chk[i])) { throw OverflowException(); }
	}

	return Point4D<T>(getX() * p.getX(), getY() * p.getY(), getZ() * p.getZ(), z4 * p.z4);
}

/* / operator method */
template <typename T>
inline Point4D<T> Point4D<T>::operator/(Point4D<T>& p) {
	/* Check whether the divisor is equal to zero or not. If so, throw DivideByZeroException */
	if (p.getX() == 0 || p.getY() == 0 || p.getZ() == 0 || z4 == 0) { throw DivideByZeroException(); }

	return Point4D<T>(getX() / p.getX(), getY() / p.getY(), getZ() / p.getZ(), z4 / p.z4);
}

template class Point4D<int>;
template class Point4D<float>;
template class Point4D<double>;