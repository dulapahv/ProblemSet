public class HeapQuiz {
	int id = 0;
}
