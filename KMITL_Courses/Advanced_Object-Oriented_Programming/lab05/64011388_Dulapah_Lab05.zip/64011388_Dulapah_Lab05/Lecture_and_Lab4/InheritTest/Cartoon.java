package InheritTest;

class Cartoon extends Drawing {
    Cartoon() {
        System.out.println("new Cartoon");
    }
}
