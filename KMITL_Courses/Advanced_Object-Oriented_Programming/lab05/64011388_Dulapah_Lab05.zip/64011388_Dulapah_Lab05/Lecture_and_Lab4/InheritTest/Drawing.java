package InheritTest;

class Drawing extends ArtWork {
    Drawing() {
        System.out.println("New Drawing");
    }
}
