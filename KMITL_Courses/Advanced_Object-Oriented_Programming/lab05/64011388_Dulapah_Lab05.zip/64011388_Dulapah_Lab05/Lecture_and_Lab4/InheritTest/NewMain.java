package InheritTest;

public class NewMain{
    public static void main(String[] args) {
        Cartoon obj = new Cartoon();
    }
}
