package Lab4Task2;

public class CountedItem extends PurchaseItem{

    private int quantity;

    CountedItem(int quantity, String name, double unitPrice){
        super(name, unitPrice);
        this.quantity = quantity;
    }

    @Override
    public double getPrice(){
        return super.getPrice() * this.quantity;
    }

    @Override
    public String toString(){
        return super.toString() + " " + this.quantity + "Units " + this.getPrice() + " $";
    }
}
