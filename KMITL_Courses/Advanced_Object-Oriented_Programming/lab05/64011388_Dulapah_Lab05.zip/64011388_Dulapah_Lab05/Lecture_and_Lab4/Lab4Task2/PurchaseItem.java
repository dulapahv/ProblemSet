package Lab4Task2;

public class PurchaseItem {
    private String name;
    private double unitPrice;

    public PurchaseItem(){
        this.name = "no item";
        this.unitPrice = 0;
    }



    public PurchaseItem(String name, double unitPrice){
        this.name = name;
        this.unitPrice = unitPrice;
    }

    @Override
    public String toString(){
        return name + " @ " + unitPrice;
    }

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }

    public double getPrice(){
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice){
        this.unitPrice = unitPrice;
    }

}
