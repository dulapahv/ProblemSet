package Lab4Task2;

public class WeightedItem extends PurchaseItem{
    private double weight;

    WeightedItem(String name, double unitPrice, double weight){
        super(name, unitPrice);
        this.weight = weight;
    }

    @Override
    public double getPrice(){
        return super.getPrice() * this.weight;
    }

    @Override
    public String toString(){
        return super.toString() + " " + this.weight + "Kg " + this.getPrice() + " $";

    }

}
