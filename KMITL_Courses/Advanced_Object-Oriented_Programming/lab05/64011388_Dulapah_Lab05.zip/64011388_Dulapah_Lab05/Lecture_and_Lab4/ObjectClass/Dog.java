package ObjectClass;

public class Dog {
    String name;

    public Dog(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        return this.name.equals(((Dog)o).name);
    }
}
