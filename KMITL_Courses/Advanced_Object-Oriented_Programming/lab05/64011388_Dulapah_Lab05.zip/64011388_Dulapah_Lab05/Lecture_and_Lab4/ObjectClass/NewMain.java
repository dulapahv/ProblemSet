package ObjectClass;

public class NewMain {
    public static void main(String[] args){
        Object object1, object2;
        object1 = new Object();
        object2 = new Object();
        System.out.println(object1.equals(object2));
        object1 = object2;
        System.out.println(object1.equals(object2));

        String str1 = "Java";
        String str2 = new String("Java");
        String str3 = "Java";
        System.out.println(str1==str2);
        System.out.println(str1==str3);

        System.out.println(str1.equals(str2));
    }

}
