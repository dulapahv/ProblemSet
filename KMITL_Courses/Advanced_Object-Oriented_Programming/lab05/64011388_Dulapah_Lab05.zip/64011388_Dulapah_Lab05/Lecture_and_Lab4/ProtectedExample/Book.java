package ProtectedExample;

public class Book { 
protected int pages = 1500; 
public void setPages (int numPages) 
{ 
pages = numPages; 
} 
public int getPages () 
{ 
return pages; 
}
} 
