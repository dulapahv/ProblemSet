package InterfaceExample;

public class PhilApp {

    public static void main(String[] args) {
//        Speaker guest = new Philosopher();
        Philosopher guest = new Philosopher();
        guest.speak();
        guest.pontificate(); //?? switch Speaker to Philosopher(line 6&7)
        System.out.println(guest.i);
        System.out.println(guest.j);
        System.out.println(guest.s);
    }
}
