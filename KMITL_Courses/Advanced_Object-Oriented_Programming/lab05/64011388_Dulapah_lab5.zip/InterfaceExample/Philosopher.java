package InterfaceExample;

public class Philosopher implements Speaker {
    int i = 10;
    int s = 16;
    public void speak() {
        System.out.println("Philosopher speaks. ");
    }
    public void pontificate() {
        System.out.println("Philosopher pontificates");
    }
}