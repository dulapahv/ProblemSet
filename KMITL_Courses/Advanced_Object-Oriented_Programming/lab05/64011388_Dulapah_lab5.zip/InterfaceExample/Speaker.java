package InterfaceExample;

interface Speaker {
    int i = 0;
    int j = 1000;
    public void speak();
}
