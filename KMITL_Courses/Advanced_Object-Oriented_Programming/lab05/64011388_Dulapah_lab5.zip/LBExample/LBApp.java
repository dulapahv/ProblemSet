package LBExample;

public class LBApp {

    public static void main(String[] args) {

        LB_2 lb2 = new LB_2();
        LB_1 lb3 = lb2; // compiles ok
        System.out.println(lb3.retValue("Today"));
    }
}
