package LBExample;

public class LB_1 {
    public String retValue(String s) {
        return "In LB_1 with " + s;
    }
}
