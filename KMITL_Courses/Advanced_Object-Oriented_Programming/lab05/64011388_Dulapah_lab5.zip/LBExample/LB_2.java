package LBExample;

class LB_2 extends LB_1 {

    @Override
    public String retValue(String s) {
        return "In LB_2 with " + s;
    }
}