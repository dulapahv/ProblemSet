package LBExample2;

class LB_1 {
    public int retValue(int i) {
        return i;
    }
    public String retValue(String s) {
        return "In LB_1 with " + s;
    }
}
