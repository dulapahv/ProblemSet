package LBExample2;

class LB_2 extends LB_1 {
    public String retValue(String s) {
        return "In LB_2 with " + s;
    }
    public String retValue(String s, int i) {
        return "Value from LB_2 " + i;
    }
}
