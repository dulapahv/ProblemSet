package LBExample2;

class TestLateBinding {

    public static void main(String[] args) {
        LB_1 lb1 = new LB_1();
        LB_2 lb2 = new LB_2();
        LB_1 lb3 = lb2;
        System.out.println("LB_1 called with 10: " + lb1.retValue(10));
        System.out.println("LB_1 called with 'Hello': " + lb1.retValue("Hello"));
        System.out.println("LB_2 called with 20: " + lb2.retValue(20));
        System.out.println("LB_2 called with 'Bye', 30: " + lb2.retValue("Bye", 30));
        System.out.println("LB_3 called with 'Today': " + lb3.retValue("Today"));
    }
}
