package SortingExample;

import java.util.Comparator;

public class FirstNameComparator implements Comparator {
    @Override
    public int compare(Object o1, Object o2) {
        return ((Contact)o1).getFirstName().compareTo(((Contact)o2).getFirstName());
    }
}
