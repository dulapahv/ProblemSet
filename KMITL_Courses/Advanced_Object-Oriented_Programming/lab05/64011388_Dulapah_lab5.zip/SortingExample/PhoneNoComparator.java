package SortingExample;

import java.util.Comparator;

public class PhoneNoComparator  implements Comparator {
    @Override
    public int compare(Object o1, Object o2) {
        return ((Contact)o1).getPhoneNo().compareTo(((Contact)o2).getPhoneNo());
    }
}
