package TestMethods;

public class Circle extends Shape{
    int i = 7;
    int j = 8;
    void draw() {
        System.out.println("Draw Circle ");
    }
    void erase() {
        System.out.println("Erase Circle ");
    }
}
