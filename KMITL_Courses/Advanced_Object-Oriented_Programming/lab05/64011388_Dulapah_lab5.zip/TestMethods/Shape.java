package TestMethods;

public class Shape {
    int i = 2;
    void draw() {
        System.out.println("Draw Shape ");
    }
    void setColor() {
        System.out.println("Set Color of Shape ");
    }
}
