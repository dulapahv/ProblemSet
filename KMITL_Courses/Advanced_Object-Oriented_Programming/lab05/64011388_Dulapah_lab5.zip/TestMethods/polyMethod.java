package TestMethods;

public class polyMethod {
    public static void main(String[] args) {
        Shape s = new Circle();
        System.out.println(s.getClass());
        s.draw();
        ((Circle)s).erase();
        s.setColor();
    }
}