package TestMethods;

public class polyVars {
    public static void main(String[] args) {
        Shape s = new Circle();
        System.out.println(s.getClass());
        int t = s.i;
        System.out.println(t);
//        int k = s.j;
//        System.out.println(k);
    }
}
