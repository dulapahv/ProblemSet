package TestVars;

class LB_1 {
    int j = 10;
    public int retValue(int i) {
        return i;
    }
    public String toString() {
        return "dfd";
    }
    public int getValue1() {
        return 1000;
    }
}
