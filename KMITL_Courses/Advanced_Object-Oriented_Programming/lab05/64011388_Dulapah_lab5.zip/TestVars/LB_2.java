package TestVars;

class LB_2 extends LB_1 {
    int j = 100;
    public int retValue(int i) {
        return i + 20;
    }
    public String retValue(String s) {
        return "In LB_2 with " + s;
    }
    public int getValue2() {
        return 100;
    }
}
