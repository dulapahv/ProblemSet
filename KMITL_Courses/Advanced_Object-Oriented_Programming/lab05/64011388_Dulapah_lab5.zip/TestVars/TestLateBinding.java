package TestVars;

class TestLateBinding {

    public static void main(String[] args) {
        LB_1 lb1 = new LB_1();
        LB_2 lb2 = new LB_2();
        LB_1 lb3 = lb2;
        System.out.println(lb1.retValue(10));
        System.out.println(lb3.retValue(10));
//        System.out.println(lb3.retValue("Today")); //??
        System.out.println(lb3.getValue1());
//        System.out.println(lb3.getValue2()); //??
        System.out.println(lb3.j);
    }
}
