/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package creatingexception;

/**
 *
 * @author Dulapah Vibulsanti
 */
public class OutOfRangeException extends Exception {

    OutOfRangeException(String message) {
        super(message);
    }

}
