package DuckSimulation1;

public abstract class Duck {

    public void performQuack() {
        System.out.println("Quack");
    }
    public void performSwim() {
        System.out.println("Swim");
    }
    public void performFly() {
        System.out.println("I can fly");
    }
    abstract void display();
}
