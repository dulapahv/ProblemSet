package DuckSimulation1;

public class MiniDuckSimulator1 {
    public static void main(String[] args) {

        Duck mallard = new MallardDuck();
        mallard.performQuack();
        mallard.performSwim();
        mallard.performFly();
        mallard.display();

        Duck redhead = new RedHeadDuck();
        redhead.performQuack();
        redhead.performSwim();
        redhead.performFly();
        redhead.display();
    }
}