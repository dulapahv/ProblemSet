package DuckSimulation1;

public class RubberDuck extends Duck {

    @Override
    public void performQuack() {
        System.out.println("Squeak");
    }

    @Override
    public void display() {
        System.out.println("I'm a rubber duckie");
    }
    @Override
    public void performFly() {
        System.out.println("I cannot fly");
    }
}