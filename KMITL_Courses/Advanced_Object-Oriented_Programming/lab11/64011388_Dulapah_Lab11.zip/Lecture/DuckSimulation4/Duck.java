package DuckSimulation4;

public abstract class Duck {
    public void performSwim() {
        System.out.println("Swim");
    }
    abstract void display();
}