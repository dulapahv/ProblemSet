package DuckSimulation4;

public interface FlyBehavior {
    public void fly();
}