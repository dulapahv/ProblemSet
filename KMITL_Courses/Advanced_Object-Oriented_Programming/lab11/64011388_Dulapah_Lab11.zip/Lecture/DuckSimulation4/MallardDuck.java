package DuckSimulation4;

public class MallardDuck extends Duck implements FlyBehavior, QuackBehavior {
    @Override
    public void display() {
        System.out.println("I'm a real Mallard duck");
    }
    @Override
    public void fly() {
        System.out.println("Mallard can fly");
    }
    @Override
    public void quack() {
        System.out.println("Mallard can quack");
    }
}