package DuckSimulation4;

public class MiniDuckSimulator4 {
    public static void main(String[] args) {

        MallardDuck mallard =
                new MallardDuck();
        mallard.quack();
        mallard.performSwim();
        mallard.fly();
        mallard.display();

        RedHeadDuck redhead =
                new RedHeadDuck();
        redhead.quack();
        redhead.performSwim();
        redhead.fly();
        redhead.display();

        RubberDuck rubber =
                new RubberDuck();
        rubber.quack();
        rubber.performSwim();
        rubber.display();
    }
}