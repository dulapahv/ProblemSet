package DuckSimulation4;

public interface QuackBehavior {
    public void quack();
}