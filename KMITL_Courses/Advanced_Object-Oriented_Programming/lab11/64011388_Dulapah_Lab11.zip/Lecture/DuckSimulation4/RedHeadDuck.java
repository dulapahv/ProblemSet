package DuckSimulation4;

public class RedHeadDuck extends Duck implements FlyBehavior, QuackBehavior {
    @Override
    public void display() {
        System.out.println("I'm a real Red Headed duck");
    }
    @Override
    public void fly() {
        System.out.println("Red Headed duck can fly");
    }
    @Override
    public void quack() {
        System.out.println("Red Headed duck can Quack");
    }
}