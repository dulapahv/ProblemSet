package DuckSimulation4;

public class RubberDuck extends Duck implements QuackBehavior {
    @Override
    public void display() {
        System.out.println("I'm a rubber duckie");
    }
    @Override
    public void quack() {
        System.out.println("A rubber duckie can squeak");
    }
}