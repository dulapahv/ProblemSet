package DuckSimulation5;

public abstract class Duck {
    // Reference variables for the behavior interface types
    FlyBehavior flyBehavior;
    QuackBehavior quackBehavior; // All duck subclasses inherit these

    public Duck() {
    }

    abstract void display();

    public void performFly() {
        flyBehavior.fly();      // Delegate to the behavior class
    }

    public void performQuack() {
        quackBehavior.quack();  // Delegate to the behavior class
    }

    public void swim() {
        System.out.println("All ducks float, even decoys!");
    }
    public void setFlyBehavior (FlyBehavior fb) {
        flyBehavior = fb;
    }
    public void setQuackBehavior(QuackBehavior qb) {
        quackBehavior = qb;
    }
}
