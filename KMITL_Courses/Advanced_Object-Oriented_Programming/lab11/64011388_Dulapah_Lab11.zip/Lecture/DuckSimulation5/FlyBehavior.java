package DuckSimulation5;


public interface FlyBehavior {
    public void fly();
}