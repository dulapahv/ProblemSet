package DuckSimulation5;

public interface QuackBehavior {
    public void quack();
}
