package DuckSimulaton0;

public abstract class Duck {

    public void performQuack() {
        System.out.println("Quack");
    }
    public void performSwim() {
        System.out.println("Swim");
    }
    abstract void display();
}
