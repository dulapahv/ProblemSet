package DuckSimulaton0;

public class MiniDuckSimulator0 {
    public static void main(String[] args) {

        Duck mallard = new MallardDuck();
        mallard.performQuack();
        mallard.display();

        Duck redhead = new RedHeadDuck();
        redhead.performQuack();
        redhead.display();
    }
}