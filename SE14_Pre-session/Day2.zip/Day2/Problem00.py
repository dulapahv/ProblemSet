print('Hello SE#14')
print('"Nice to meet you all~"')
