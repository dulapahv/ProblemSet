romaji = ['rei', 'ichi', 'ni', 'san', 'yon',
		  'go', 'roku', 'nana', 'hachi', 'kyu']
usin = int(input())
print(f'{usin} --> {romaji[usin]}')
